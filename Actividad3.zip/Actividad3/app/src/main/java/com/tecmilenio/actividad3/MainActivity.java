package com.tecmilenio.actividad3;

import android.graphics.Color;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GestureDetectorCompat;

// TODO: Importante agregar comentarios en el código ya que es parte de los criterios de evaluación.

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener, View.OnClickListener {

    private GestureDetectorCompat gestureDetector;
    private ConstraintLayout layout;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.layout);
        textView = findViewById(R.id.text_view);

        Button button = findViewById(R.id.button);
        button.setOnClickListener(this);

        gestureDetector = new GestureDetectorCompat(this, this);
        gestureDetector.setOnDoubleTapListener(this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // Es importante interceptar los eventos de touch para manipularlos en nuestra app.
        gestureDetector.onTouchEvent(event);

        return super.onTouchEvent(event);
    }

    @Override
    public void onClick(View view) {
        textView.setText(getString(R.string.event, "onClick"));
        // Al dar click en el botón, la pantalla va a cambiar a gris calor.
        // TODO: Deben hacer que la pantalla cambie de color con todos los demás gestos.
        layout.setBackgroundColor(Color.LTGRAY);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onSingleTapConfirmed"));
        // TODO: Cambiar el color de la pantalla.
        layout.setBackgroundColor(Color.DKGRAY);
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onDoubleTap"));
        // TODO: Cambiar el color de la pantalla.
        layout.setBackgroundColor(Color.GREEN);
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onDoubleTapEvent"));
        // TODO: Cambiar el color de la pantalla.
        layout.setBackgroundColor(Color.RED);
        return false;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onDown"));
        // TODO: Cambiar el color de la pantalla.
        layout.setBackgroundColor(Color.BLUE);
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onShowPress"));
        // TODO: Cambiar el color de la pantalla.
        layout.setBackgroundColor(Color.YELLOW);
    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onSingleTapUp"));
        // TODO: Cambiar el color de la pantalla.
        layout.setBackgroundColor(Color.BLACK);
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        textView.setText(getString(R.string.event, "onScroll"));
        // TODO: Cambiar el color de la pantalla.
        layout.setBackgroundColor(Color.CYAN);
        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {
        textView.setText(getString(R.string.event, "onLongPress"));
        // TODO: Cambiar el color de la pantalla.
        layout.setBackgroundColor(Color.MAGENTA);
    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        textView.setText(getString(R.string.event, "onFling"));
        // TODO: Cambiar el color de la pantalla.
        layout.setBackgroundColor(Color.WHITE);
        return false;
    }
}
