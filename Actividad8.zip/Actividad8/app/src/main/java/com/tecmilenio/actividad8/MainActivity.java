package com.tecmilenio.actividad8;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int PERMISSION_CAMERA_REQUEST_CODE = 101;
    private static final int PERMISSION_PHONE_REQUEST_CODE = 102;

    private Button openActivityButton;
    private Button openBrowserButton;
    private Button openMapsButton;
    private Button openPhoneButton;
    private Button openCameraButton;
    private String phoneSelected;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        openActivityButton = findViewById(R.id.btn_open_activity);
        openActivityButton.setOnClickListener(this);
        openBrowserButton = findViewById(R.id.btn_open_browser);
        openBrowserButton.setOnClickListener(this);
        openMapsButton = findViewById(R.id.btn_open_maps);
        openMapsButton.setOnClickListener(this);
        openPhoneButton = findViewById(R.id.btn_open_phone);
        openPhoneButton.setOnClickListener(this);
        openCameraButton = findViewById(R.id.btn_open_camera);
        openCameraButton.setOnClickListener(this);

    }

    // region View.OnClickListener
    @Override
    public void onClick(View view) {
        if (view.equals(openActivityButton)) {
            openPhone("tel:332388184");
        } else if (view.equals(openBrowserButton)) {
            openPhone("tel:3323881885");
        } else if (view.equals(openMapsButton)) {
            openPhone("tel:3323881883");
        } else if (view.equals(openPhoneButton)) {
            openPhone("tel:3323881882");
        } else if (view.equals(openCameraButton)) {
            openPhone("tel:3323881880");
        }
    }

    private void openActivity() {
        Intent intent = new Intent(this, Activity1.class);
        startActivity(intent);
    }

    private void openBrowser() {
        Uri uri = Uri.parse("https://google.com.mx");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    private void openMaps() {
        Uri uri = Uri.parse("geo:25.6280159,-100.3065559");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setPackage("com.google.android.apps.maps");
        startActivity(intent);
    }

    private void openPhone(String phone) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            // La aplicación sí tiene permisos para realizar esta acción.
            Uri uri = Uri.parse(phone);
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(uri);
            startActivity(intent);
        } else {
            phoneSelected = phone;
            // La aplicación no tiene permisos para realizar esta acción y hay que solicitar el permiso al usuario.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, PERMISSION_PHONE_REQUEST_CODE);
        }
    }

    private void openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            // La aplicación sí tiene permisos para realizar esta acción.
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivity(intent);
        } else {
            // La aplicación no tiene permisos para realizar esta acción y hay que solicitar el permiso al usuario.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PERMISSION_CAMERA_REQUEST_CODE);
        }
    }
    // endregion

    // region Permissions

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case PERMISSION_PHONE_REQUEST_CODE:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openPhone(phoneSelected);
                } else {
                    Toast.makeText(this, "La aplicación no tiene acceso al teléfono", Toast.LENGTH_SHORT).show();
                }
                break;
            case PERMISSION_CAMERA_REQUEST_CODE:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openCamera();
                } else {
                    Toast.makeText(this, "La aplicación no tiene acceso a la cámara", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }

    // endregion
}
