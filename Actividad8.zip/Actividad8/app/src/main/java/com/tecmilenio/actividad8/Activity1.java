package com.tecmilenio.actividad8;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Activity1 extends AppCompatActivity implements View.OnClickListener {

    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity1);

        editText = findViewById(R.id.edit_text);
        Button button = findViewById(R.id.btn_next_activity);
        button.setOnClickListener(this);
    }

    // region View.OnClickListener methods
    @Override
    public void onClick(View view) {
        // Se utiliza el método trim para ignorar los espacios vacíos del String.
        String name = editText.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "Ingresa un valor", Toast.LENGTH_SHORT).show();
        } else {
            goToActivity2(name);
        }
    }
    // endregion

    private void goToActivity2(String name) {
        // Creamos un objeto de tipo intent para poder cambiar de Activity a Activity2.
        Intent intent = new Intent(this, Activity2.class);

        // Agregamos un extra de tipo String al intent.
        // En este caso el texto de nuestro EditText con el identificador "name".
        intent.putExtra(Activity2.INTENT_NAME, name);

        // Lamamos a Activity2.
        startActivity(intent);

        // Terminamos esta actividad.
        finish();
    }
}