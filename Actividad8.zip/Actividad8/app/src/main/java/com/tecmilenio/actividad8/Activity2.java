package com.tecmilenio.actividad8;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {

    protected static final String INTENT_NAME = "name";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);

        TextView textView = findViewById(R.id.text_view);

        // Obtenemos el Intent que trae los datos.
        Intent intent = getIntent();
        // Obtenemos el String del Intent con el identificador "name".
        String name = intent.getStringExtra(INTENT_NAME);
        textView.setText(name);
    }
}
