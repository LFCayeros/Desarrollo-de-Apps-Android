package com.tecmilenio.actividad11;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Definimos el texto para identificador.
    TextView txtId;

    // Definimos los campos de nombre, telefono, direccion y email.
    EditText editName;
    EditText editPhone;
    EditText editAddress;
    EditText editEmail;

    // Definimos el manejador de la base de datos.
    DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtId = findViewById(R.id.txtId);
        editName = findViewById(R.id.editName);
        editPhone = findViewById(R.id.editPhone);
        editAddress = findViewById(R.id.editAddress);
        editEmail = findViewById(R.id.editEmail);
        dbHandler = new DBHandler(this, null, null, 1);
    }

    public void addClient(View view) {
        // Definimos el nombre,la direccion, el telefono y el correo
        String name = editName.getText().toString().trim();
        String phone = editPhone.getText().toString().trim();
        String address = editAddress.getText().toString().trim();
        String email = editEmail.getText().toString().trim();

        // Creamos el object client.
        Client client = new Client(name, phone, address, email);

        // Agregamos el objeto a la base de datos.
        long result = dbHandler.addClient(client);

        if (result == -1) {
            txtId.setText(R.string.not_added);
        } else {
            txtId.setText(R.string.added);
        }

        editName.setText("");
        editPhone.setText("");
        editAddress.setText("");
        editEmail.setText("");
    }

    public void findClientByName(View view) {
        // Definimos el nombre.
        String name = editName.getText().toString().trim();

        // Buscamos el producto.
        Client client = dbHandler.findClientByName(name);

        // Verificamos si se encontró o no.
        if (client == null) {
            txtId.setText(R.string.not_found);
            editName.setText("");
            editPhone.setText("");
            editAddress.setText("");
            editEmail.setText("");
        } else {
            txtId.setText(String.valueOf(client.get_id()));
            editName.setText(client.get_name());
            editPhone.setText(client.get_phone());
            editAddress.setText(client.get_address());
            editEmail.setText(client.get_email());
        }
    }

    public void findClientByNumber(View view) {
        // Definimos el numero.
        String phone = editPhone.getText().toString().trim();

        // Buscamos el numero.
        Client client = dbHandler.findClientByNumber(phone);

        // Verificamos si se encontró o no.
        if (client == null) {
            txtId.setText(R.string.not_found);
            editName.setText("");
            editPhone.setText("");
            editAddress.setText("");
            editEmail.setText("");
        } else {
            txtId.setText(String.valueOf(client.get_id()));
            editName.setText(client.get_name());
            editPhone.setText(client.get_phone());
            editAddress.setText(client.get_address());
            editEmail.setText(client.get_email());
        }
    }

    public void deleteClient(View view) {
        // Definimos el nombre.
        String name = editName.getText().toString().trim();

        // Verificamos si se borró el producto.
        if (dbHandler.deleteClient(name)) {
            txtId.setText(R.string.deleted);
        } else {
            txtId.setText(R.string.not_found);
        }

        editName.setText("");
        editPhone.setText("");
        editAddress.setText("");
        editEmail.setText("");
    }
}