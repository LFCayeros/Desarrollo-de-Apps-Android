package com.tecmilenio.actividad11;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "clientBD.db";
    private static final String TABLE_CLIENTS = "clients";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_NAME = "_name";
    private static final String COLUMN_PHONE = "_phone";
    private static final String COLUMN_ADDRESS = "_address";
    private static final String COLUMN_EMAIL = "_email";

    DBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Creamos la estructura de la tabla.
        String CREATE_TABLE_CLIENTS = "CREATE TABLE " + TABLE_CLIENTS +
                " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_PHONE + " TEXT, " +
                COLUMN_ADDRESS + "TEXT, " +
                COLUMN_EMAIL + "TEXT" +
                ")";

        // Ejecutamos la creación de la tabla.
        sqLiteDatabase.execSQL(CREATE_TABLE_CLIENTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // Borramos la tabla de clientes si existe.
        String DROP_TABLE_CLIENTS = "DROP TABLE IF EXISTS " + TABLE_CLIENTS;
        sqLiteDatabase.execSQL(DROP_TABLE_CLIENTS);

        // Creamos lan nueva tabla
        onCreate(sqLiteDatabase);
    }

    /*
     * Función para agregar un cliente
     */
    long addClient(Client client) {
        // Creamos el contenedor de valores.
        ContentValues values = new ContentValues();
        // Agregamos cada dato requerido de nuestra columna.
        values.put(COLUMN_NAME, client.get_name());
        values.put(COLUMN_PHONE, client.get_phone());
        values.put(COLUMN_ADDRESS, client.get_address());
        values.put(COLUMN_EMAIL, client.get_email());

        // Obtenemos el objeto de la base de datos.
        SQLiteDatabase database = this.getWritableDatabase();
        // Insertamos nuestro registro en la tabla.
        long result = database.insert(TABLE_CLIENTS, null, values);

        // Cerramos la base de datos.
        database.close();

        return result;
    }

    /*
     * Función para buscar un cliente por nombre.
     */
    Client findClientByName(String name) {
        // Definimos el query de búsqueda.
        String query = "SELECT * FROM " + TABLE_CLIENTS + " WHERE " + COLUMN_NAME + " = " + "\"" + name + "\"";

        // Obtenemos el objeto de la base de datos.
        SQLiteDatabase database = this.getWritableDatabase();
        // Realizamos la búsqueda.
        Cursor cursor = database.rawQuery(query, null);

        // Creamos un objeto de tipo Client.
        Client client = new Client();

        // Verificamos si se encontró algún registro.
        if (cursor.moveToFirst()) {
            // Obtenemos el id con el primer valor del string.
            client.set_id(Integer.parseInt(cursor.getString(0)));
            // Obtenemos el name con el segundo valor del string.
            client.set_name(cursor.getString(1));
            // Obtenemos el phone con el tercer valor del string.
            client.set_phone(cursor.getString(2));
            // Obtenemos el address con el cuarto valor del string.
            client.set_address(cursor.getString(3));
            //Obtenemos el email con el quinto valor del string.
            client.set_email(cursor.getString(4));

            // Cerramos el cursor.
            cursor.close();
        } else {
            client = null;
        }

        // Cerramos la base de datos.
        database.close();

        // Regresamos el objeto client
        return client;
    }

    /*
     * Función para buscar un cliente por nombre.
     */
    Client findClientByNumber(String phone) {
        // Definimos el query de búsqueda.
        String query = "SELECT * FROM " + TABLE_CLIENTS + " WHERE " + COLUMN_PHONE + " = " + "\"" + phone + "\"";

        // Obtenemos el objeto de la base de datos.
        SQLiteDatabase database = this.getWritableDatabase();
        // Realizamos la búsqueda.
        Cursor cursor = database.rawQuery(query, null);

        // Creamos un objeto de tipo Client.
        Client client = new Client();

        // Verificamos si se encontró algún registro.
        if (cursor.moveToFirst()) {
            // Obtenemos el id con el primer valor del string.
            client.set_id(Integer.parseInt(cursor.getString(0)));
            // Obtenemos el name con el segundo valor del string.
            client.set_name(cursor.getString(1));
            // Obtenemos el phone con el tercer valor del string.
            client.set_phone(cursor.getString(2));
            // Obtenemos el address con el cuarto valor del string.
            client.set_address(cursor.getString(3));
            //Obtenemos el email con el quinto valor del string.
            client.set_email(cursor.getString(4));

            // Cerramos el cursor.
            cursor.close();
        } else {
            client = null;
        }

        // Cerramos la base de datos.
        database.close();

        // Regresamos el objeto client
        return client;
    }

    /*
     * Función para borrar un cliente
     */
    boolean deleteClient(String name) {
        // Creamos el valor de retorno como falso.
        // Falso = no se encontró o no se eliminó.
        // Verdadero = se eliminó.
        boolean result = false;

        // Buscamos el cliente con la función que creamos.
        Client client = findClientByName(name);

        // Si es distinto de nulo, es que encontró algo.
        if (client != null) {
            // Creamos el query de eliminar.
            String query = "DELETE FROM " + TABLE_CLIENTS +
                    " WHERE " + COLUMN_NAME + " = " +
                    "\"" + name + "\"";

            // Obtenemos el objeto de la base de datos.
            SQLiteDatabase database = this.getWritableDatabase();

            // Ejecutamos el query para eliminar el registro.
            database.execSQL(query);

            // Cerramos la base de datos.
            database.close();

            // Retornamos el resultado verdadero.
            result = true;
        }

        return result;
    }
}
