package com.tecmilenio.actividad5;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;


public class MainActivity extends AppCompatActivity implements OnClickListener, OnCheckedChangeListener, CompoundButton.OnCheckedChangeListener {
    // RadioGroup.
    private RadioGroup radioGroup1;
    // RadioButton.
    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private RadioButton radioButton3;
    private RadioButton radioButton4;
    // ToggleButton.
    ToggleButton toggleButton;
    // CheckBox.
    private CheckBox checkBox1;
    private CheckBox checkBox2;
    // Switch.
    private SwitchCompat switchButton;
    // Variable para el total
    public float total = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.txt_integer);
        int integer = 100;
        textView.setText(String.valueOf(integer));

        // Button.
        Button button = findViewById(R.id.button);
        button.setOnClickListener(this);

        // RadioGroup1.
        radioGroup1 = findViewById(R.id.radio_group_1);
        radioGroup1.setOnCheckedChangeListener(this);
        radioButton1 = findViewById(R.id.radio_button_1);
        radioButton2 = findViewById(R.id.radio_button_2);
        radioButton3 = findViewById(R.id.radio_button_3);
        radioButton4 = findViewById(R.id.radio_button_4);

        // ToggleButton.
        toggleButton = findViewById(R.id.togggle_button);
        toggleButton.setOnCheckedChangeListener(this);

        // CheckBox.
        checkBox1 = findViewById(R.id.checkbox_1);
        checkBox1.setOnCheckedChangeListener(this);
        checkBox2 = findViewById(R.id.checkbox_2);
        checkBox2.setOnCheckedChangeListener(this);

        // Switch.
        switchButton = findViewById(R.id.switch_button);
        switchButton.setOnCheckedChangeListener(this);
    }

    /**
     * OnClickListener methods
     */
    @Override
    public void onClick(View view) {
        Toast.makeText(this, getString(R.string.button_clicked), Toast.LENGTH_SHORT).show();
    }

    /**
     * OnCheckedChangeListener methods
     * radioGroup - Referencia al objeto RadioGroup que pertene el RadioButton que fue seleccionado.
     * radioButtonIndex - Indice del RadioButton que fue seleccionado.
     */
    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
        if (radioGroup.equals(radioGroup1)) {
            switch (checkedId) {
                case R.id.radio_button_1:
                    radioButton1.setChecked(true);
                    total = total + 22_700;
                    break;
                case R.id.radio_button_2:
                    radioButton2.setChecked(true);
                    total = total + 35_500;
                    break;
                case R.id.radio_button_3:
                    radioButton3.setChecked(true);
                    total = total + 32_900;
                    break;
                case R.id.radio_button_4:
                    radioButton4.setChecked(true);
                    total = 0;
                    break;
                default:
                    break;
            }
        }
    }

    /**o
     * CompoundButton.OnCheckedChangeListener methods
     */
    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean checked) {
        if (compoundButton.equals(toggleButton)) {
            Toast.makeText(this, getString(R.string.toggle_button_text, checked), Toast.LENGTH_SHORT)
                    .show();
        } else if (compoundButton.equals(checkBox1)) {
            Toast.makeText(this, getString(checked ? R.string.check_box_checked : R.string.check_box_unchecked, checkBox1.getText()), Toast.LENGTH_SHORT)
                    .show();
        } else if (compoundButton.equals(checkBox2)) {
            Toast.makeText(this, getString(checked ? R.string.check_box_checked : R.string.check_box_unchecked, checkBox2.getText()), Toast.LENGTH_SHORT)
                    .show();
        } else if (compoundButton.equals(switchButton)) {
            Toast.makeText(this, getString(checked ? R.string.switch_text_on : R.string.switch_text_off), Toast.LENGTH_SHORT)
                    .show();
        }
    }
}

