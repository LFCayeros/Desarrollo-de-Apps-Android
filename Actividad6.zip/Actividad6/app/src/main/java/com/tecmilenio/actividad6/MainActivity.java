package com.tecmilenio.actividad6;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, TimePicker.OnTimeChangedListener, DatePicker.OnDateChangedListener, View.OnClickListener {

    private final Calendar calendar = Calendar.getInstance();

    private Spinner spinner;
    private String selectedSpecialty = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Spinner
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Especialidades_array, R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        // Time picker
        TimePicker timePicker = findViewById(R.id.time_picker);
        timePicker.setOnTimeChangedListener(this);

        // Date picker
        DatePicker datePicker = findViewById(R.id.date_picker);
        datePicker.setOnDateChangedListener(this);

        // Image button.
        ImageButton imageButton = findViewById(R.id.img_button);
        imageButton.setOnClickListener(this);
    }

    // region AdapterView.OnItemSelectedListener methods
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if (adapterView.equals(spinner)) {
            selectedSpecialty = adapterView.getItemAtPosition(i).toString();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        if (adapterView.equals(spinner)) {
            selectedSpecialty = "";
        }
    }
    // endregion

    // region TimePicker.OnTimeChangedListener
    @Override
    public void onTimeChanged(TimePicker timePicker, int hour, int minute) {
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
    }
    // endregion

    // region DatePicker.OnDateChangedListener
    @Override
    public void onDateChanged(DatePicker datePicker, int year, int month, int dayOfMonth) {
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
    }
    // endregion

    // region View.OnClickListener
    @Override
    public void onClick(View view) {
        DateFormat dateFormat = SimpleDateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL);
        String date  = dateFormat.format(calendar.getTime());

        Toast.makeText(this, getString(R.string.selected_data, selectedSpecialty, date), Toast.LENGTH_LONG).show();
    }
    // endregion
}
